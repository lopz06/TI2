# TI2_Exercicio1
* Exercicio1 de TI2 - PUC-MG
* Auto-avaliação - 5/5
* Atividade simples e eficiente, não tem muito do que desviar do seu exemplo em vídeo.
