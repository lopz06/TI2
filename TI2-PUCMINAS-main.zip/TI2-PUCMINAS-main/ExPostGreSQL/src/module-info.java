module ExPostGreSQL {
	requires java.sql;
}