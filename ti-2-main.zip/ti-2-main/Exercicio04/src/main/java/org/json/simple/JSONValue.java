package org.json.simple;

public class JSONValue {

	public static Object parse(String body) {
		// TODO Auto-generated method stub
		return null;
	}

}
