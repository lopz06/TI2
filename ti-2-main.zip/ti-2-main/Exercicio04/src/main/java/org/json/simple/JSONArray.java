package org.json.simple;

public class JSONArray {

	public void add(JSONObject item) {
		// TODO Auto-generated method stub
		
	}

}
